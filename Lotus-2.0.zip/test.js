function urlify(text) {
    var urlRegex = /(https?:\/\/[^\s]+)/g;
    var urlStart = text.search(urlRegex)
    var afterLink = text.substring(urlStart)
    //console.log(afterLink)
    urlEnd = afterLink.search(" ")
    var finalString = afterLink.substring(0,urlEnd)
    return finalString

   // return text.find(urlRegex)
    // or alternatively
    // return text.replace(urlRegex, '<a href="$1">$1</a>')
}

var text = "Find me at http://www.example.com and also at http://stackoverflow.com";
var html = urlify(text);
console.log(html)


string_to_array = function (str) {
    return str.trim().split(" ");
};
console.log(string_to_array("Robin Singh"));